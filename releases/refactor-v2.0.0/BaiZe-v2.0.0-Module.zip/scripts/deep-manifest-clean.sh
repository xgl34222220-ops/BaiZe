#!/system/bin/sh
set -u

MODDIR=${0%/*}
# Keep module data at the root; implementations live under scripts/.
case "$MODDIR" in */scripts) MODDIR=${MODDIR%/scripts} ;; esac
SCRIPTDIR="$MODDIR"
[ ! -d "$MODDIR/scripts" ] || SCRIPTDIR="$MODDIR/scripts"
TRIGGER=${2:-manual}
STATE_DIR=${BAIZE_STATE_DIR:-/data/adb/baize-v2}
CONFIG="$STATE_DIR/config.conf"
WHITELIST="$STATE_DIR/whitelist.conf"
DEEP_RULES=${BAIZE_DEEP_RULES:-$MODDIR/config/deep.rules}
LOCK_DIR="$STATE_DIR/run.lock"
RUNNING_FILE="$STATE_DIR/running.env"
STOP_FILE="$STATE_DIR/stop"
STATE_FILE="$STATE_DIR/deep_scan.env"
TARGETS_FILE="$STATE_DIR/deep_scan.targets"
MANIFEST_FILE="$STATE_DIR/deep_scan.manifest0"
CURSOR_FILE="$STATE_DIR/deep_scan.cursor"
ACCUM_FILE="$STATE_DIR/deep_clean.accum.env"
HISTORY_FILE="$STATE_DIR/history.tsv"
REPORT_DIR="$STATE_DIR/reports"
LOG_DIR="$STATE_DIR/logs"
# ABI 解析辅助。测试夹具可能只暂存部分脚本，缺失时退回到内联实现。
if [ -f "$SCRIPTDIR/abi-resolve.sh" ]; then
  . "$SCRIPTDIR/abi-resolve.sh"
else
  baize_device_abis() { printf 'arm64-v8a\narmeabi-v7a\nx86_64\n'; }
  baize_resolve_engine() {
    for _abi in $(baize_device_abis); do
      [ -x "$1/bin/$_abi/$2" ] && { printf '%s\n' "$1/bin/$_abi/$2"; return 0; }
    done
    return 1
  }
  baize_require_engine() {
    [ -n "${3:-}" ] && [ -x "$3" ] && { printf '%s\n' "$3"; return 0; }
    baize_resolve_engine "$1" "$2" && return 0
    echo "当前架构没有可用的 $2，请重新刷入完整模块" >&2
    return 8
  }
fi
SNAPSHOT_ENGINE=$(baize_require_engine "$MODDIR" baize_deep_snapshot "${BAIZE_DEEP_SNAPSHOT_ENGINE:-}" 2>/dev/null || true)

mkdir -p "$STATE_DIR" "$REPORT_DIR" "$LOG_DIR"
[ -f "$WHITELIST" ] || : >"$WHITELIST"

state_value() { sed -n "s/^$1=//p" "$STATE_FILE" 2>/dev/null | tail -n 1; }
summary_value() { summary_file=$1; summary_key=$2; sed -n "s/^$summary_key=//p" "$summary_file" 2>/dev/null | tail -n 1; }
uint_value() { value=$1; fallback=${2:-0}; case "$value" in ''|*[!0-9]*) value=$fallback ;; esac; echo "$value"; }
file_sha() { [ -f "$1" ] && sha256sum "$1" 2>/dev/null | awk 'NR==1{print $1}' || echo missing; }
human_bytes() { awk -v b="$1" 'BEGIN { if (b>=1073741824) printf "%.2f GB",b/1073741824; else if(b>=1048576) printf "%.2f MB",b/1048576; else if(b>=1024) printf "%.2f KB",b/1024; else printf "%.0f B",b }'; }
proc_start_ticks() { [ -r "/proc/$1/stat" ] && awk '{print $22}' "/proc/$1/stat" 2>/dev/null || echo 0; }
pid_is_task() {
  pid=$1
  [ "$pid" -gt 1 ] 2>/dev/null || return 1
  [ -r "/proc/$pid/cmdline" ] || return 1
  cmdline=$(tr '\000' ' ' <"/proc/$pid/cmdline" 2>/dev/null)
  case "$cmdline" in *deep-manifest-clean.sh*|*cleaner.sh*|*task-worker.sh*|*worker-runner.sh*|*baize_deep_snapshot*|*apk-scanner.sh*|*apk-scanner.sh*|*apk-cleaner.sh*|*apk-cleaner.sh*|*one-pass-scan.sh*|*cache-snapshot*|*cache-lane-worker.sh*|*deep-scan-manifest.sh*|*deep-manifest-clean.sh*|*profile-cleaner.sh*|*organizer-worker.sh*|*worker-runner.sh*|*task-worker.sh*|*baize_deep_snapshot*) return 0 ;; esac
  return 1
}

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  old_pid=$(sed -n '1p' "$LOCK_DIR/pid" 2>/dev/null)
  case "$old_pid" in ''|*[!0-9]*) old_pid=0 ;; esac
  if [ "$old_pid" -gt 1 ] && kill -0 "$old_pid" 2>/dev/null && pid_is_task "$old_pid"; then
    echo "已有扫描或清理任务正在运行"
    exit 3
  fi
  rm -rf -- "$LOCK_DIR" 2>/dev/null
  rm -f "$RUNNING_FILE" 2>/dev/null
  mkdir "$LOCK_DIR" 2>/dev/null || { echo "无法恢复任务锁，请重试"; exit 4; }
fi
printf '%s\n' "$$" >"$LOCK_DIR/pid"
printf '%s\n' "$(proc_start_ticks $$)" >"$LOCK_DIR/start_ticks"
cleanup_lock() { rm -f "$RUNNING_FILE" 2>/dev/null; rm -rf -- "$LOCK_DIR" 2>/dev/null; }
trap cleanup_lock EXIT
rm -f "$STOP_FILE"

[ -x "$SNAPSHOT_ENGINE" ] || { echo "深度不可变快照引擎缺失，请重新刷入完整模块" >&2; exit 8; }
[ -s "$STATE_FILE" ] && [ -s "$MANIFEST_FILE" ] && [ -f "$CURSOR_FILE" ] || {
  echo "没有可用的深度逐文件快照，请先完成深度扫描"
  exit 6
}

snapshot_id=$(state_value snapshot_id)
epoch=$(uint_value "$(state_value epoch)" 0)
manifest_sha=$(state_value manifest_sha)
expected_targets_sha=$(state_value targets_sha)
expected_whitelist_sha=$(state_value whitelist_sha)
expected_rules_sha=$(state_value rules_sha)
max_file_bytes=$(uint_value "$(state_value max_file_bytes)" 268435456)
now=$(date +%s)
age=$((now - epoch))
if [ "$epoch" -le 0 ] || [ "$age" -lt 0 ] || [ "$age" -gt 1800 ] || [ -z "$snapshot_id" ]; then
  echo "深度扫描快照已过期，请重新扫描"
  exit 6
fi
[ "$(file_sha "$MANIFEST_FILE")" = "$manifest_sha" ] || { echo "深度逐文件快照校验失败"; exit 7; }
[ "$(file_sha "$TARGETS_FILE")" = "$expected_targets_sha" ] || { echo "深度目标快照校验失败"; exit 7; }
[ "$(file_sha "$WHITELIST")" = "$expected_whitelist_sha" ] || { echo "白名单已变化，请重新扫描"; exit 7; }
[ -f "$DEEP_RULES" ] && [ "$(file_sha "$DEEP_RULES")" = "$expected_rules_sha" ] || { echo "深度规则库已变化，请重新扫描"; exit 7; }

# Rules, overrides and the chosen risk ceiling form one snapshot policy.
# A policy edit after scanning must not leave an older, broader delete plan live.
expected_builtin_risk_sha=$(state_value builtin_risk_sha)
expected_user_risk_sha=$(state_value user_risk_sha)
expected_config_sha=$(state_value config_sha)
for policy_kind in builtin user config; do
  case "$policy_kind" in
    builtin) policy_expected=$expected_builtin_risk_sha; policy_file=${BAIZE_BUILTIN_RISK_OVERRIDES:-$MODDIR/config/risk-overrides.conf} ;;
    user) policy_expected=$expected_user_risk_sha; policy_file=${BAIZE_RISK_OVERRIDES:-$STATE_DIR/risk-overrides.conf} ;;
    config) policy_expected=$expected_config_sha; policy_file=$CONFIG ;;
  esac
  [ -z "$policy_expected" ] || [ "$(file_sha "$policy_file")" = "$policy_expected" ] || {
    echo "深度风险策略已变化，请重新扫描"
    exit 7
  }
done


STAMP=$(date '+%Y-%m-%d_%H-%M-%S')
REPORT_FILE="$REPORT_DIR/$STAMP-deep-clean.tsv"
SUMMARY_FILE="$LOCK_DIR/deep-clean-summary.env"
LOG_FILE="$LOG_DIR/$STAMP-deep-clean.log"
START_EPOCH=$(date +%s)

"$SNAPSHOT_ENGINE" clean \
  --manifest "$MANIFEST_FILE" \
  --cursor "$CURSOR_FILE" \
  --report "$REPORT_FILE" \
  --summary "$SUMMARY_FILE" \
  --whitelist "$WHITELIST" \
  --progress "$RUNNING_FILE" \
  --stop "$STOP_FILE" \
  --max-file-bytes "$max_file_bytes"
code=$?
rm -f "$STATE_DIR/index/meta.env"

if [ "$(summary_value "$SUMMARY_FILE" accounting)" != "cumulative-journal-v1" ]; then
  echo "深度清理未生成可信累计账本，快照已保留；设备重启、旧版非零游标或账本损坏后需要重新扫描（代码 $code）" >&2
  [ "$code" -ne 0 ] && exit "$code"
  exit 71
fi

uncertain=$(uint_value "$(summary_value "$SUMMARY_FILE" uncertain_records)" 0)
uncertain_bytes=$(uint_value "$(summary_value "$SUMMARY_FILE" uncertain_bytes)" 0)
recovered_unsealed=$(uint_value "$(summary_value "$SUMMARY_FILE" recovered_unsealed_records)" 0)
recovery_audit=$(uint_value "$(summary_value "$SUMMARY_FILE" recovery_requires_audit)" 0)
remaining=$(uint_value "$(summary_value "$SUMMARY_FILE" remaining)" 0)
cursor=$(uint_value "$(summary_value "$SUMMARY_FILE" cursor)" 0)
records=$(uint_value "$(summary_value "$SUMMARY_FILE" records)" 0)

# The native journal is authoritative across shell crashes and retries. Never add
# last invocation's accumulator to these cumulative values.
total_files=$(uint_value "$(summary_value "$SUMMARY_FILE" files)" 0)
total_dirs=$(uint_value "$(summary_value "$SUMMARY_FILE" dirs)" 0)
total_bytes=$(uint_value "$(summary_value "$SUMMARY_FILE" bytes)" 0)
total_skipped=$(uint_value "$(summary_value "$SUMMARY_FILE" skipped)" 0)
total_errors=$(uint_value "$(summary_value "$SUMMARY_FILE" errors)" 0)

if [ "$code" -eq 9 ]; then
  stopped=1
  result="深度不可变快照清理已停止，已保存到第 ${cursor}/${records} 条，累计释放 $(human_bytes "$total_bytes")"
elif [ "$code" -eq 0 ]; then
  stopped=0
  remaining=0
  result="深度不可变快照清理完成，累计释放 $(human_bytes "$total_bytes")"
else
  stopped=0
  result="深度不可变快照清理失败，代码 $code，进度保留在 ${cursor}/${records}"
fi

if [ "$recovery_audit" -gt 0 ]; then
  result="$result；账本含本次启动内恢复的成功操作记录；统计为已记录删除量，不保证等于实际可用空间增量"
fi
if [ "$uncertain" -gt 0 ]; then
  result="$result；中断窗口有 $uncertain 条记录去向不确定（最多 $(human_bytes "$uncertain_bytes")），未计入释放量"
fi

END_EPOCH=$(date +%s)
elapsed=$((END_EPOCH - START_EPOCH))
latest_tmp="$STATE_DIR/latest.env.tmp.$$"
{
  echo "mode=deep-clean"
  echo "time=$(date '+%Y-%m-%d %H:%M:%S')"
  echo "schema=clean-result-v2"
  echo "files=$total_files"
  echo "regular_files=$total_files"
  echo "empty_dirs=$total_dirs"
  echo "bytes=$total_bytes"
  echo "skipped=$total_skipped"
  echo "errors=$total_errors"
  echo "protected_items=$total_skipped"
  echo "deep_manifest_records=$records"
  echo "deep_manifest_cursor=$cursor"
  echo "deep_remaining_records=$remaining"
  echo "deep_stopped=$stopped"
  echo "deep_uncertain_records=$uncertain"
  echo "deep_uncertain_bytes=$uncertain_bytes"
  echo "deep_recovered_unsealed_records=$recovered_unsealed"
  echo "deep_recovery_requires_audit=$recovery_audit"
  echo "deep_accounting=cumulative-journal-v1"
  echo "elapsed=$elapsed"
  echo "engine=deep-manifest-v1"
  echo "result=$result"
} >"$latest_tmp" && mv -f "$latest_tmp" "$STATE_DIR/latest.env" || exit 71
cp -f "$REPORT_FILE" "$REPORT_DIR/latest.tsv" 2>/dev/null || true
{
  echo "----------------------------------------"
  echo "$result"
  echo "扫描快照: $snapshot_id"
  echo "清理进度: $cursor/$records | 剩余: $remaining"
  echo "累计清理: $total_files 个文件 / $total_dirs 个目录 / $(human_bytes "$total_bytes")"
  echo "保护跳过: $total_skipped | 失败: $total_errors | 本次耗时: ${elapsed}s"
} >>"$LOG_FILE"
cp -f "$LOG_FILE" "$LOG_DIR/latest.log"
# History is an idempotent projection of the snapshot ledger, not an invocation
# delta. A shell killed before this write is repaired by the next resume.
history_tmp="$HISTORY_FILE.tmp.$$"
if [ -f "$HISTORY_FILE" ]; then
  awk -F '\t' -v id="$snapshot_id" '!($2 == "deep-clean" && $10 == id)' "$HISTORY_FILE" >"$history_tmp" || exit 71
else
  : >"$history_tmp" || exit 71
fi
printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
  "$(date '+%Y-%m-%d %H:%M:%S')" deep-clean "$total_bytes" "$total_files" "$total_dirs" "$total_errors" \
  "$result" "$TRIGGER" "深度不可变快照|$total_bytes|$total_files" "$snapshot_id" >>"$history_tmp" || exit 71
tail -n 100 "$history_tmp" >"$history_tmp.last" && mv -f "$history_tmp.last" "$HISTORY_FILE" || exit 71
rm -f "$history_tmp"
if [ "$code" -eq 0 ]; then
  rm -f "$STATE_FILE" "$TARGETS_FILE" "$MANIFEST_FILE" "$CURSOR_FILE" "$STATE_DIR/deep_scan.manifest.env" "$ACCUM_FILE"
fi

echo "$result"
echo "进度: $cursor/$records | 剩余: $remaining | 文件: $total_files | 目录: $total_dirs | 跳过: $total_skipped | 失败: $total_errors"
[ "$code" -eq 9 ] && exit 9
exit "$code"
