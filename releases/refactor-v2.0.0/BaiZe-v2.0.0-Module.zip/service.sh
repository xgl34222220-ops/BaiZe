#!/system/bin/sh
# set -u：未定义变量视为错误。清理脚本以 root 身份删文件，
# 变量拼写错误静默展开成空串会造成 rm -rf "/foo" 这类事故。
set -u
# Canonical Magisk module root: /data/adb/modules/baize_v2; MODDIR remains portable for KernelSU and APatch.
# Runtime migration supersedes deep-pipeline-v1 and clears stale queues, locks and pre-manifest deep snapshots.
MODDIR=${0%/*}
# Keep module data at the root; implementations live under scripts/.
case "$MODDIR" in */scripts) MODDIR=${MODDIR%/scripts} ;; esac
SCRIPTDIR="$MODDIR"
[ ! -d "$MODDIR/scripts" ] || SCRIPTDIR="$MODDIR/scripts"
APP_ID=io.github.xgl34222220.baize
STATE_DIR=/data/adb/baize-v2
STATE="$STATE_DIR/module.env"
CONFIG="$STATE_DIR/config.conf"
rm -rf "$MODDIR/webroot" "$MODDIR/webui" "$MODDIR/www" "$MODDIR/ksu-webui" 2>/dev/null || true
mkdir -p "$STATE_DIR" "$STATE_DIR/logs" "$STATE_DIR/reports"
chmod 0700 "$STATE_DIR"
RUNTIME_SCHEMA=deep-manifest-v1
SCHEMA_FILE="$STATE_DIR/runtime-schema"
current_schema=$(sed -n '1p' "$SCHEMA_FILE" 2>/dev/null)
if [ "$current_schema" != "$RUNTIME_SCHEMA" ]; then
  rm -rf "$STATE_DIR/run.lock" "$STATE_DIR/cache-lane.lock" "$STATE_DIR/cache-lane" "$STATE_DIR/scheduler-requests" "$STATE_DIR/scheduler-skips"
  rm -f "$STATE_DIR/running.env" "$STATE_DIR/worker.env" "$STATE_DIR/scheduler.env" \
    "$STATE_DIR/supervisor.env" "$STATE_DIR/scheduler-queue.tsv" "$STATE_DIR/supervisor.stop" \
    "$STATE_DIR/stop" "$STATE_DIR/deep_scan.env" "$STATE_DIR/deep_scan.targets" \
    "$STATE_DIR/deep_scan.manifest0" "$STATE_DIR/deep_scan.cursor" \
    "$STATE_DIR/deep_scan.manifest.env" "$STATE_DIR/deep_clean.accum.env"
  rm -f "$STATE_DIR"/scheduler-retry-*.count "$STATE_DIR"/scheduler-retry-*.until \
    "$STATE_DIR"/scheduler-fail-*.count "$STATE_DIR"/scheduler-pause-*.until 2>/dev/null || true
  mkdir -p "$STATE_DIR/scheduler-requests" "$STATE_DIR/scheduler-skips"
  echo "$RUNTIME_SCHEMA" >"$SCHEMA_FILE"
fi
[ -f "$CONFIG" ] || cp -f "$MODDIR/config/default.conf" "$CONFIG" 2>/dev/null
chmod 0600 "$CONFIG" 2>/dev/null || true
count=0; while [ "$(getprop sys.boot_completed)" != 1 ] && [ "$count" -lt 180 ]; do sleep 1; count=$((count+1)); done
install_result=missing
if [ -x "$SCRIPTDIR/app-installer.sh" ]; then sh "$SCRIPTDIR/app-installer.sh" ensure >/dev/null 2>&1; case $? in 0) install_result=ready;; 11) install_result=signature_mismatch;; *) install_result=failed;; esac; fi
version=$(sed -n 's/^version=//p' "$MODDIR/module.prop" 2>/dev/null | tail -n 1)
version_code=$(sed -n 's/^versionCode=//p' "$MODDIR/module.prop" 2>/dev/null | tail -n 1)
root_framework=Magisk; [ -n "${KSU:-}" ] && root_framework=KernelSU; [ -n "${APATCH:-}" ] && root_framework=APatch
{
 echo "boot_epoch=$(date +%s)"; echo "app_installed=$(pm path "$APP_ID" >/dev/null 2>&1 && echo 1 || echo 0)"; echo "app_install_result=$install_result"; echo "app_version=$(dumpsys package "$APP_ID" 2>/dev/null | sed -n 's/.*versionName=//p' | head -n 1)"; echo "rules_ready=$([ -f "$MODDIR/config/deep.rules" ] && echo 1 || echo 0)"; echo "cleaner_ready=$([ -x "$SCRIPTDIR/cleaner.sh" ] && echo 1 || echo 0)"; echo "scheduler_ready=$([ -x "$SCRIPTDIR/scheduler.sh" ] && echo 1 || echo 0)"; echo "module_version=$version"; echo "module_version_code=$version_code"; echo "root_framework=$root_framework";
} >"$STATE.tmp" && mv -f "$STATE.tmp" "$STATE"
chmod 0600 "$STATE" 2>/dev/null || true
[ -x "$SCRIPTDIR/rules-validator.sh" ] && sh "$SCRIPTDIR/rules-validator.sh" >"$STATE_DIR/rules-validation.txt" 2>&1 || true
if [ -x "$SCRIPTDIR/supervisor.sh" ] && [ -x "$SCRIPTDIR/scheduler.sh" ]; then exec sh "$SCRIPTDIR/supervisor.sh"; fi
while true; do sleep 3600; done
